import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
const cards = characters.concat(characters);
const shuffledCards = shuffle(cards);


function shuffle(cards) {
  const shuffled = cards.slice();
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export default function App() {
  const [grid, setGrid] = useState([]);
  const [firstCard, setFirstCard] = useState(null);
  const [secondCard, setSecondCard] = useState(null);
  const [attempts, setAttempts] = useState(0);
  const [matches, setMatches] = useState(0);

  useEffect(() => {
  
  setGrid(shuffledCards.map((character, index) => ({
    id: index,
    character,
    matched: false,
    selected: false,
  })));
}, []);


  function selectCard(card) {
    if (card.matched || card.selected || secondCard !== null) {
      return; }
    card.selected = true;
    setGrid([...grid]);
    if (firstCard === null) {
      setFirstCard(card);
    } else {
      setSecondCard(card);
      setAttempts(attempts + 1);
      if (firstCard.character === card.character) {
       
        firstCard.matched = true;
        card.matched = true;
        setMatches(matches + 1);
        setFirstCard(null);
        setSecondCard(null);
        if (matches + 1 === characters.length) {
          
          alert(`Congratulations! You completed the game in ${attempts} attempts.`);
          setGrid(shuffledCards.map((character, index) => ({
            id: index,
            character,
            matched: false,
            selected: false,
          })));
          setFirstCard(null);
          setSecondCard(null);
          setAttempts(0);
          setMatches(0);
        }
      } else {
        
        setTimeout(() => {
          firstCard.selected = false;
          card.selected = false;
          setGrid([...grid]);
          setFirstCard(null);
          setSecondCard(null);
        }, 1000);
      }
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.text}>Attempts: {attempts}</Text>
        <Text style={styles.text}>Matches: {matches}</Text>
      </View>
      <View style={styles.grid}>
        {grid.map(card => (
          <TouchableOpacity
            key={card.id}
            style={[styles.card, card.matched && styles.matched, card.selected && styles.selected]}
            onPress={() => selectCard(card)}
            disabled={card.matched || secondCard !== null}
          >
            <Text style={styles.text}>{card.character}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>

  ); } 
  
const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: '#fff',
alignItems: 'center',
justifyContent: 'center',
},
header: {
flexDirection: 'row',
justifyContent: 'space-between',
alignItems: 'center',
width: '100%',
paddingHorizontal: 40,
paddingVertical: 0,
borderBottomWidth: 10,
borderColor: '#ccc',
},
text: {
fontSize: 18,
},
grid: {
  flex: 1,
  flexDirection: 'row',
  flexWrap: 'wrap',
  justifyContent: 'center',
  alignItems: 'center',
  padding: 20,
  width: 240, 
},
card: {
  backgroundColor: '#f2f2f2',
  borderRadius: 5,
  margin: 5,
  width: 40, 
  height:70,
  justifyContent: 'center',
  alignItems: 'center',
},

matched: {
backgroundColor: '#6eff6e',
},
selected: {
backgroundColor: '#ff6e6e',
},
});